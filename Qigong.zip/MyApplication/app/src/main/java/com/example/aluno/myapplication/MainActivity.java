package com.example.aluno.myapplication;

import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer sino, tema;
    private TextView mTextField;
    private TextView textTempo;
    private SeekBar seekMinutos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mTextField = findViewById(R.id.mTextField);
        textTempo = findViewById(R.id.textTempo);
        seekMinutos = findViewById(R.id.seekBar);
        sino = MediaPlayer.create(this, R.raw.sino);
        tema = MediaPlayer.create(this, R.raw.qigong);
        tema.start();

        seekMinutos.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float x = seekBar.getProgress();
                textTempo.setText(String.valueOf(x));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }


    String text = "30";
    int seconds = Integer.valueOf(text);

    //get how many repeat
    String repeatText = "5";
    int repeat = Integer.valueOf(repeatText);

    int count= 0;

    CountDownTimer countDownTimer = new CountDownTimer(seconds * 1000, 1000) {
        @Override
        public void onTick(long millis) {
            mTextField.setText("time:" + (int)(millis / 1000));
        }

        @Override
        public void onFinish() {
            mTextField.setText("Finished!");
            sino.start();
            count++;
            //check if count still less than repeat number
            if(true){
                Runnable r = new Runnable() {
                    public void run() {
                        countDownTimer.start();
                    }};

                new Handler().postDelayed(r,2000); //delay repeat timer 2 seconds

            }
            else{
                countDownTimer.cancel();
                count = 0;
            }
        }
    }.start();


}


